-- --------------------------------------------------------
-- Сервер:                       127.0.0.1
-- Версія сервера:               5.6.26 - MySQL Community Server (GPL)
-- ОС сервера:                   Win32
-- HeidiSQL Версія:              9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for yii2basic
CREATE DATABASE IF NOT EXISTS `yii2basic` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `yii2basic`;


-- Dumping structure for таблиця yii2basic.kgr
CREATE TABLE IF NOT EXISTS `kgr` (
  `pi` int(10) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `nam` varchar(50) NOT NULL,
  `dat` longtext,
  `sen` longtext,
  PRIMARY KEY (`pi`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Dumping data for table yii2basic.kgr: ~3 rows (приблизно)
/*!40000 ALTER TABLE `kgr` DISABLE KEYS */;
INSERT INTO `kgr` (`pi`, `nam`, `dat`, `sen`) VALUES
	(0000000001, 'Початок', 'Початок - науково-фантастичний трилер, головний герой отримує пропозицію від якої він не може відмовитись. Він повинен зародити ідею в мозку людини щоб вона зробила велику помилку, від цього залежить побачить він сім\'ю чи ні. Оцінка кінотеатру 10/10.', '13:20\r\n\r\n15:10\r\n\r\n17:40\r\n\r\n19:15\r\n'),
	(0000000002, 'Легенда Г\'ю Гласса', 'Легенда Г\'ю Гласса — драматичний фільм-трилер, знятий Алехандро Гонсалесом Іньярріту за однойменним романом Майкла Панке 2002 року видання, який ґрунтувався на подіях із життя реального персонажа — колоніста Г\'ю Гласса. Оцінка кінотеатру 9/10.', '11:20\r\n\r\n13:40\r\n\r\n17:00\r\n\r\n20:00'),
	(0000000003, 'Драйв', 'Чудовий гонщик — вдень він виконує каскадерські трюки на знімальних майданчиках Голлівуду, а вночі веде ризиковану гру. Але один небезпечний контракт — і за його життя призначена нагорода.Тепер, щоб залишитися живим і врятувати свою чарівну сусідку, він повинен робити те, що вміє найкраще — віртуозно втікати від переслідування. Оцінка кінотеатру 9/10.', '10:20\r\n\r\n12:40\r\n\r\n14:30\r\n\r\n16:00');
/*!40000 ALTER TABLE `kgr` ENABLE KEYS */;


-- Dumping structure for таблиця yii2basic.userinformation
CREATE TABLE IF NOT EXISTS `userinformation` (
  `id` int(1) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Dumping data for table yii2basic.userinformation: ~1 rows (приблизно)
/*!40000 ALTER TABLE `userinformation` DISABLE KEYS */;
INSERT INTO `userinformation` (`id`, `name`, `email`, `password`) VALUES
	(5, 'da', 'da@da.com', '$2y$13$yduueGsQiWwNjC/n6lCAGOX86huafG6LTt3jyJ616ew'),
	(6, 'h', 'h@h.com', '$2y$13$PtIOesWzojbNoRbcOcJhv.OTNCmDcO0yDU6w9GhUict');
/*!40000 ALTER TABLE `userinformation` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
